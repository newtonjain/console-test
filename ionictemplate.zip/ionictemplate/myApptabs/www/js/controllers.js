angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  console.log('testing Edge Performance');
  for(var i = 0; i< 2000; i++) {
    console.log('The quick brown fox jumps over the %s lazy dog', i);
    
  }
  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
    for(var i = 0; i< 2000; i++) {
//     console.group('browser:  Group A')
// console.log('browser:  I\'m message 1 in group 1');
// console.group('browser:  Group B');
// console.log('browser:  I\'m  message 1/2 in group 2');
// console.log('browser:  I\'m  message 2/2 in group 2');
// console.groupEnd()
// console.log('browser:  I\'m message 2 in group 1');
// console.groupCollapsed('browser:  Group C');
// console.log('browser:  I\'m message 1/2 in (collapsed) group 3');
// console.log('browser:  I\'m message 2/2 in (collapsed) group 3');
// console.groupEnd();
// console.log('browser:  I\'m message 3 in group 1');
// console.groupEnd();
console.log('VSS.SDK.min.js:3 No handler found on any channel for message: {"id":1,"methodName":null,"instanceId":"wdgeswm.iterationtracker.iterationtracker-hub-observer","instanceContext":{"user":{"id":"26abdbf9-5f733","name":"Newton Jain","email":"n","uniqueName":"neja@microsoft.com"},"team":{"id":"3b71d7f9-a5a6-466f-9c7","name":"OS Team"},"project":{"id":"8-aa9b-fc6929290322","name":"OS"},"collection":{"id":"cb70f-1b49d8ee7564","name":"microsoft","uri":"https://microsoft.visualstudio.com/","relativeUri":"/"},"account":{"id":"b64-2049-45a0-9343-84479ff6aebb","name":"microsoft","uri":"https://microsoft.visualstudio.com/","relativeUri":"/"},"host":{"isAADAccount":true,"id":"cb70f-1b49d8ee7564","name":"microsoft","uri":"https://microsoft.visualstudio.com/","relativeUri":"/","hostType":4,"scheme":"https","authority":"microsoft.visualstudio.com"}},"params":null,"jsonrpc":"2.0"}', i);
    
  }
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});



