# How to Make a Codepen 

**options:**
1. Fork the [Codepen by @raibutera](http://codepen.io/Rai/pen/rVjzoX?)
2. Use the [Template](/docs/codepen-template.html)
